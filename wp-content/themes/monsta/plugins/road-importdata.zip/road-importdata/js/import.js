jQuery(document).ready(function(){ 
	// road-importdata
	jQuery("#form-refresh").get(0).submit();
});
